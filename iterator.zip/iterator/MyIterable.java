package iterator;

public interface MyIterable {
    MyIterator iterator();
}
