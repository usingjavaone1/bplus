package iterator;

public class Cilent {
    public static void main(String[] args) {
        int[] data = new int[]{1,2,3,4,5,6,7,8,9};
        for (int element : data) {
            System.out.print(element + " ");
        }
        System.out.println();
        MyArrayList myList = new MyArrayList(data);
        MyIterator myIterator = myList.iterator();
        while (myIterator.hasNext()) {
            int currentElement = myIterator.next();
            System.out.print(currentElement+" ");
        }
    }
}
