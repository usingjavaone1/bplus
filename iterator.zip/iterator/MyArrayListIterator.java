package iterator;

public class MyArrayListIterator implements MyIterator {
    private int[] array;
    private int currentPosition;
    @Override
    public boolean hasNext() {

        return this.currentPosition < (this.array.length);
    }

    @Override
    public int next() {
        this.currentPosition++;
        return array[this.currentPosition-1];
    }
    public MyArrayListIterator(int[] array) {
        this.array = array;
        this.currentPosition = 0;
    }
}
