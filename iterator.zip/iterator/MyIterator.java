package iterator;

public interface MyIterator {
    boolean hasNext();
    int next();


}
