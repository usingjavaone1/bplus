package iterator;

import java.util.ArrayList;

public class MyArrayList implements MyIterable {
    private int[] array;

    public MyArrayList(int[] array) {
        this.array = array;
    }

    @Override
    public MyIterator iterator() {
        return new MyArrayListIterator(array);
    }
}
